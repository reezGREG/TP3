# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.1.6/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.1.6/maven-plugin/reference/html/#build-image)
* [Spring Web](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#web)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#data.sql.jpa-and-spring-data)
* [Validation](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#io.validation)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#using.devtools)
* [Thymeleaf](https://docs.spring.io/spring-boot/docs/3.1.6/reference/htmlsingle/index.html#web.servlet.spring-mvc.template-engines)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)

### Réponses pour l'etape 13

1. **Parametrage de l'URL d'appel /greeting :**  
   Nous avons parametre l'URL d'appel /greeting à l'aide de l'annotation `@GetMapping("/greeting")` placee au-dessus de la methode `greeting` dans la classe `HelloWorldController`.

2. **Choix du fichier HTML à afficher :**  
   Le choix du fichier HTML à afficher est défini par la valeur retournée dans la méthode `greeting` du contrôleur. La ligne `return "greeting";` spécifie que le template à utiliser est nommé "greeting".

3. **Envoi du nom à qui nous disons bonjour avec le second lien :**  
   Le nom à qui nous disons bonjour est envoyé en utilisant le paramètre de requête `name` dans l'URL. Dans la méthode `greeting`, ce paramètre est récupéré à l'aide de `@RequestParam(name="nameGET", required=false, defaultValue="World") String nameGET`. Ainsi, le nom est extrait de l'URL et assigné à la variable `nameGET`.

## Étape 17 - Differences remarquées

Après avoir redémarré l'application et accédé à la console H2 à l'URL http://localhost:8080/h2-console, j'ai remarqué une différence significative. Suite à l'ajout de la classe `Address` annotée avec `@Entity` dans le package `model`, une nouvelle table semblant correspondre à cette classe a été créée dans la base de données in-memory.

En examinant la console H2, j'ai pu constater l'existence d'une nouvelle table appelée `ADDRESS`, ce qui semble confirmer la création réussie de l'entité `Address` dans la base de données.

Cette observation confirme le comportement habituel de Hibernate : lorsqu'une classe est annotée avec `@Entity` et que l'application est redémarrée, Hibernate génère automatiquement la table correspondante dans la base de données. 


## Étape 18 - Explication de l'apparition de la nouvelle table

L'apparition de la nouvelle table dans la base de données découle de l'utilisation de Hibernate-JPA en conjonction avec Spring. L'annotation `@Entity` placée sur la classe `Address` indique à Hibernate qu'il s'agit d'une entité à stocker en base de données. Au démarrage de l'application, Hibernate génère automatiquement la table correspondante, nommée ici `ADDRESS`, destinée à contenir les instances de la classe `Address`.

Hibernate simplifie la correspondance entre les objets Java et les tables de la base de données. L'utilisation de `@Entity` permet de gérer les entités Java comme des objets, laissant à Hibernate la tâche de mapper ces objets vers les tables de la base de données. Cette intégration transparente facilite la manipulation des données tout en garantissant leur persistance dans la base de données.

### Étape 20 - Vérification des données ajoutées dans la console H2

**Vérification du contenu de la table `Address`:**

En exécutant une requête SELECT sur la table `Address`, j'ai pu constater que les données ajoutées via le fichier `data.sql` étaient présentes dans la base de données. Les deux enregistrements que j'ai insérés étaient visibles dans la table `Address`, confirmant ainsi que les données ont été ajoutées avec succès.

Cette méthode simplifiée d'ajout de données via le fichier `data.sql` offre une façon pratique d'intégrer des données initiales dans la base de données au démarrage de l'application.

### Étape 22 - Explication de l'annotation `@Autowired`

L'annotation `@Autowired` est utilisée pour effectuer l'injection de dépendances dans Spring. Elle permet à Spring de résoudre et d'injecter automatiquement les dépendances associées à une classe.

Dans le contexte d'une classe de contrôleur tel que `AddressController`, l'annotation `@Autowired` utilisée avec `AddressRepository` permet à Spring de fournir automatiquement une instance de `AddressRepository` au contrôleur. Cela permet au contrôleur d'utiliser l'instance d'`AddressRepository` pour interagir avec la base de données sans avoir besoin d'instancier manuellement `AddressRepository`.

### Étape 30 - Ajout de Bootstrap à mon Projet

Pour intégrer Bootstrap à mon projet, j'ai utilisé une méthode simple en utilisant les liens CDN (Content Delivery Network).

# Étapes Suivies :

**Inclusion des liens CDN dans le fichier HTML :**

Dans mon fichier HTML de projet, j'ai ajouté les liens CDN de Bootstrap pour le CSS et le JavaScript directement dans les sections `<head>` et `<body>` respectivement :

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

** Utilisation des classes Bootstrap : **

Après avoir inclus les liens CDN, j'ai pu utiliser les classes CSS de Bootstrap dans mon code HTML pour bénéficier de ses styles prédéfinis, de sa grille de mise en page, de ses composants prêts à l'emploi, etc.

Cette méthode rapide m'a permis d'intégrer Bootstrap à mon projet sans avoir à télécharger et inclure localement les fichiers Bootstrap. Les liens CDN m'ont offert un accès facile aux fonctionnalités de Bootstrap directement depuis leur serveur.
