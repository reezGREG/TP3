package com.maven.TP3and4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp3and4Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp3and4Application.class, args);
	}

}
